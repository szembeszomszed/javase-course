public class TömbLétrehozásFeltöltésListázás1 {
  public static void main(String[] args) {
    int[] tömb={6, 12, -5, 0, 8, 2, 6, 44, 9, 7};       //1
    System.out.println("A tömb elemei: ");
    for(int i=0; i<=9; i++)                             //2
      System.out.print(tömb[i]+", ");                   //3
    System.out.println();
  }
}