public class EgyjegyűSzámok1 {
  public static void main(String[] args) {
    System.out.print("Pozitív egyjegyű számok: ");
    for(int i=0; i<10; i++)                             //1
      System.out.print(i+", ");                         //2
    System.out.println();                               //3
  }
}