public class KétSzámÖsszege {
  public static void main(String[] args) {
    System.out.println("Két szám összege");
    int a=extra.Console.readInt("Egyik szám: ");
    int b=extra.Console.readInt("Másik szám: ");
    int összeg=a+b;
    System.out.println("A két szám összege: "+összeg);
  }
}