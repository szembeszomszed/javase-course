public class DuplaSzám2 {
  public static void main(String[] args) {
    System.out.println("Szám kétszerese");
    int x, xDupla;                                      //1
    x = extra.Console.readInt("Szám: ");
    xDupla = 2*x;
    System.out.println("A szám kétszerese: "+xDupla);
  }
}