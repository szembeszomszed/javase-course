public class Vakáció1 {
  public static void main(String[] args) {
    System.out.println("      ó\n     ió\n    ció");
    System.out.println("   áció");
    System.out.println("  káció");
    System.out.println(" akáció");
    System.out.println("Vakáció");
  }
}