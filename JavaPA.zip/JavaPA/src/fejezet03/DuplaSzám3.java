public class DuplaSzám3 {
  public static void main(String[] args) {
    System.out.println("Szám kétszerese");
    int x = extra.Console.readInt("Szám: ");            //1
    int xDupla = 2*x;                                   //2
    System.out.println("A szám kétszerese: "+xDupla);
  }
}